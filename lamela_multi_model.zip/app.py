from flask import Flask, request, render_template
import numpy as np
import joblib
from decimal import Decimal, ROUND_HALF_UP

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def home():
    prediction = None
    if request.method == "POST":
        try:
            tip = request.form["tip"]
            H = float(request.form["H"])
            B = float(request.form["B"])  # Trenutno ne koristi

            if tip == "FŽ":
                lamela = 1 if H <= 103 else int((H - 104) // 75) + 2
            elif tip == "PŽ-S":
                lamela = 1 if H <= 124 else int((H - 125) // 70) + 2
            else:
                raise ValueError("Nepoznat tip lamele.")

            reg = joblib.load(f"regresori/{tip}_reg_{lamela}.joblib")
            sc = joblib.load(f"regresori/{tip}_scaler_{lamela}.joblib")
            raster = reg.predict(sc.transform(np.array([[H]])))[0]

            r1 = Decimal(str(raster)).quantize(Decimal("0.05"), rounding=ROUND_HALF_UP)
            zaokruzen = float(r1.quantize(Decimal("0.1"), rounding=ROUND_HALF_UP))

            prediction = f"Tip: {tip}, Broj lamela: {lamela}, Raster: {zaokruzen} mm"

        except Exception as e:
            prediction = f"Greška: {str(e)}"
    return render_template("index.html", prediction=prediction)

if __name__ == "__main__":
    app.run(debug=True)
